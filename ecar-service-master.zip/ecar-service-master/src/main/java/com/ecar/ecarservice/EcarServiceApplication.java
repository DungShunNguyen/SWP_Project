package com.ecar.ecarservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcarServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcarServiceApplication.class, args);
    }

}
