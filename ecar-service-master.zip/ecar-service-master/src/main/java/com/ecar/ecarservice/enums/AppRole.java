package com.ecar.ecarservice.enums;

public enum AppRole {
    CUSTOMER,
    STAFF,
    TECHNICIAN,
    ADMIN
}
